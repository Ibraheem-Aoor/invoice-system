<?php if(Auth::check()): ?>
    <?php $__env->startSection('title', 'الصفحة الريسية'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'نظام الفواتير'); ?>
<?php endif; ?>

<?php $__env->startSection('css'); ?>
    <!--  Owl-carousel css-->
    <link href="<?php echo e(URL::asset('assets/plugins/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" />
    <!-- Maps css -->
    <link href="<?php echo e(URL::asset('assets/plugins/jqvmap/jqvmap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">الصفحة الرئيسية</h4>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- row -->
    <div class="row row-sm">
        <div class="col-xl-3 col-lg-6 col-md-6 col-xm-12">
            <div class="card overflow-hidden sales-card bg-primary-gradient">
                <div class="pl-3 pt-3 pr-3 pb-2 pt-0">
                    <div class="">
                        <h6 class=" mb-3 tx-12 text-white">إجمالي الفواتير</h6>
                    </div>
                    <div class="pb-0 mt-0">
                        <div class="d-flex">
                            <div class="">
                                <h4 class=" tx-20 font-weight-bold mb-1 text-white">
                                    <?php echo e($data['invoicesTotal']); ?></h4>
                                <p class="mb-0 tx-12 text-white op-7">
                                    <?php echo e($data['invoicesCount']); ?></p>
                            </div>
                            <span class="float-right my-auto mr-auto">
                                <i class="fas fa-arrow-circle-up text-white"></i>
                                <span class="text-white op-7">100%</span>
                            </span>
                        </div>
                    </div>
                </div>
                <span id="compositeline" class="pt-1">5,9,5,6,4,12,18,14,10,15,12,5,8,5,12,5,12,10,16,12</span>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-xm-12">
            <div class="card overflow-hidden sales-card bg-danger-gradient">
                <div class="pl-3 pt-3 pr-3 pb-2 pt-0">
                    <div class="">
                        <h6 class=" mb-3 tx-12 text-white">الفواتير الغير مدفوعة</h6>
                    </div>
                    <div class="pb-0 mt-0">
                        <div class="d-flex">
                            <div class="">
                                <h4 class=" tx-20 font-weight-bold mb-1 text-white" id="inPaidAmount">

                                    <?php echo e($data['totalOfInPaid']); ?>

                                </h4>

                                <p class="mb-0 tx-12 text-white op-7" id="inPaid">
                                    <?php echo e($data['numOfInPaid']); ?>

                                </p>
                            </div>
                            <span class="float-right my-auto mr-auto">
                                <i class="fas fa-arrow-circle-down text-white"></i>
                                <span class="text-white op-7">
                                    <?php if($data['numOfInPaid'] == 0): ?>
                                        0%
                                    <?php else: ?>
                                        <?php echo e($data['numOfInPaid'] / $data['invoicesCount']); ?>

                                    <?php endif; ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                <span id="compositeline2" class="pt-1">3,2,4,6,12,14,8,7,14,16,12,7,8,4,3,2,2,5,6,7</span>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-xm-12">
            <div class="card overflow-hidden sales-card bg-success-gradient">
                <div class="pl-3 pt-3 pr-3 pb-2 pt-0">
                    <div class="">
                        <h6 class=" mb-3 tx-12 text-white">الفواتير المدفوعة</h6>
                    </div>
                    <div class="pb-0 mt-0">
                        <div class="d-flex">
                            <div class="">
                                <h4 class=" tx-20 font-weight-bold mb-1 text-white" id="paidAmount">
                                    <?php echo e($data['totalPaid']); ?>

                                </h4>
                                <p class="mb-0 tx-12 text-white op-7" id="paid">
                                    <?php echo e($data['numOfPaid']); ?>

                                </p>
                            </div>
                            <span class="float-right my-auto mr-auto">
                                <i class="fas fa-arrow-circle-up text-white"></i>
                                <span class="text-white op-7">
                                    <?php if($data['numOfPaid'] == 0): ?>
                                        <?php echo e(0); ?>

                                    <?php else: ?>
                                        <?php echo e($data['numOfPaid'] / $data['invoicesCount']); ?>


                                    <?php endif; ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                <span id="compositeline3"
                    class="pt-1">5,10,5,20,22,12,15,18,20,15,8,12,22,5,10,12,22,15,16,10</span>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-xm-12">
            <div class="card overflow-hidden sales-card bg-warning-gradient">
                <div class="pl-3 pt-3 pr-3 pb-2 pt-0">
                    <div class="">
                        <h6 class=" mb-3 tx-12 text-white">الفواتير المدفوعة جزئيا</h6>
                    </div>
                    <div class="pb-0 mt-0">
                        <div class="d-flex">
                            <div class="">
                                <h4 class=" tx-20 font-weight-bold mb-1 text-white" id="partPaidAmount">
                                    <?php echo e($data['totalOfPartPaid']); ?>

                                </h4>
                                <p class="mb-0 tx-12 text-white op-7" id="partPaid">
                                    <?php echo e($data['numOfPartPaid']); ?>

                                </p>
                            </div>
                            <span class="float-right my-auto mr-auto">
                                <i class="fas fa-arrow-circle-down text-white"></i>
                                <span class="text-white op-7">
                                    <?php if($data['numOfPartPaid'] == 0): ?>
                                        <?php echo e(0); ?>

                                    <?php else: ?>
                                        <?php echo e($data['numOfPartPaid'] / $data['invoicesCount']); ?>

                                    <?php endif; ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                <span id="compositeline4" class="pt-1">5,9,5,6,4,12,18,14,10,15,12,5,8,5,12,5,12,10,16,12</span>
            </div>
        </div>
    </div>
    <!-- row closed -->


    <!-- row opened -->
    <div class="row row-sm">
        <div class="col-sm-6 ">
            <div class="card">
                <div class="card-body">
                    <canvas id="myChart2" width="200" height="200">
                    </canvas>
                </div>
            </div>
        </div>
        <div class="col-sm-6 ">
            <div class="card">
                <div class="card-body">
                    <canvas id="myChart" width="200" height="200">
                    </canvas>
                </div>
            </div>
        </div>

    </div>
    <!-- row closed -->



    </div>
    </div>
    <!-- Container closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <!--Internal  Chart.bundle js -->
    <script src="<?php echo e(URL::asset('assets/plugins/chart.js/Chart.bundle.min.js')); ?>"></script>
    <!-- Moment js -->
    <script src="<?php echo e(URL::asset('assets/plugins/raphael/raphael.min.js')); ?>"></script>
    <!--Internal  Flot js-->
    <script src="<?php echo e(URL::asset('assets/plugins/jquery.flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/jquery.flot/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/jquery.flot/jquery.flot.resize.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/jquery.flot/jquery.flot.categories.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/dashboard.sampledata.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/chart.flot.sampledata.js')); ?>"></script>
    <!--Internal Apexchart js-->
    <script src="<?php echo e(URL::asset('assets/js/apexcharts.js')); ?>"></script>
    <!-- Internal Map -->
    <script src="<?php echo e(URL::asset('assets/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/modal-popup.js')); ?>"></script>
    <!--Internal  index js -->
    <script src="<?php echo e(URL::asset('assets/js/index.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.vmap.sampledata.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var inpaid = $('#inPaid').text();
        var paid = $('#paid').text();
        var partPaid = $('#partPaid').text();

        var inPaidAmount = $('#inPaidAmount').text();
        var paidAmount = $('#paidAmount').text();
        var partPaidAmount = $('#partPaidAmount').text();
        // donughtChar SetUp
        const data = {
            labels: [
                'غير مدفوعة',
                'المدفوعة',
                'مدفوعة جزئيا'
            ],
            datasets: [{
                label: 'نسب الفواتير ',
                data: [inpaid, paid, partPaid],
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 205, 86)'
                ],
                hoverOffset: 4
            }]
        };

        // donughtChar SetUp
        const config = {
            type: 'doughnut',
            data: data,
            options: {}
        };

        // donughtChar render
        const myChart = new Chart(
            document.getElementById('myChart'),
            config
        );
    </script>



    <script>
        const data_2 = {
            labels: [
                'غير مدفوعة',
                'المدفوعة',
                'مدفوعة جزئيا'
            ],
            datasets: [{
                label: 'المبالغ حسب الفواتير',
                data: [inPaidAmount, paidAmount, partPaidAmount],
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 205, 86)'
                ],
                hoverOffset: 4
            }]
        };

        const config_2 = {
            type: 'bar',
            data: data_2,
            options: {}
        };
        const myChart2 = new Chart(
            document.getElementById('myChart2'),
            config_2
        );
    </script>

    





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wampFolder\www\myFiles\Laravel_Projects\invoice-system\resources\views/index.blade.php ENDPATH**/ ?>