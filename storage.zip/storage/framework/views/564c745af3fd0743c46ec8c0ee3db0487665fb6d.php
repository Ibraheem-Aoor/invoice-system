<?php echo e($slot); ?>

<?php /**PATH G:\wampFolder\www\myFiles\Laravel_Projects\invoice-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>