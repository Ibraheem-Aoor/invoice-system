<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2020 <a href="#">Ibraheem Al-Awoor</a>. All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
<?php /**PATH G:\wampFolder\www\myFiles\Laravel_Projects\invoice-system\resources\views/layouts/footer.blade.php ENDPATH**/ ?>