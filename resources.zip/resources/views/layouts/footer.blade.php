<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2020 <a href="#">Ibraheem Al-Awoor</a>. All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
