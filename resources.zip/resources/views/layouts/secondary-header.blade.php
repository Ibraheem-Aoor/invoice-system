<!-- main-header opened -->
			<div class="main-header sticky side-header nav nav-item">
				<div class="container-fluid">
					<div class="main-header-left ">
						<div class="responsive-logo">
							<a href="{{ url('/' . $page='index') }}"><img src="{{URL::asset('assets/img/brand/logo.png')}}" class="logo-1" alt="logo"></a>
							<a href="{{ url('/' . $page='index') }}"><img src="{{URL::asset('assets/img/brand/logo-white.png')}}" class="dark-logo-1" alt="logo"></a>
							<a href="{{ url('/' . $page='index') }}"><img src="{{URL::asset('assets/img/brand/favicon.png')}}" class="logo-2" alt="logo"></a>
							<a href="{{ url('/' . $page='index') }}"><img src="{{URL::asset('assets/img/brand/favicon.png')}}" class="dark-logo-2" alt="logo"></a>
						</div>
						<div class="app-sidebar__toggle" data-toggle="sidebar">
							<a class="open-toggle" href="#"><i class="header-icon fe fe-align-left" ></i></a>
							<a class="close-toggle" href="#"><i class="header-icons fe fe-x"></i></a>
						</div>

					</div>
					<div class="main-header-right">
						<div class="nav nav-item  navbar-nav-right ml-auto">
                            <a class="new nav-link" href="{{route('login')}}" style="cursor: pointer;margin-top:10%;font-size:15px">
                                <button class="alert alert-success">
                                    تسجيل الدخول
                                </button>
                            </a>
						</div>
						<div class="nav nav-item  navbar-nav-right ml-auto">
                            <a class="new nav-link" href="{{route('register')}}" style="cursor: pointer;margin-top:10%;font-size:15px">
                                <button class="alert alert-information">
                                انشاء حساب
                                </button>
                            </a>
						</div>
					</div>
				</div>
			</div>
<!-- /main-header -->
